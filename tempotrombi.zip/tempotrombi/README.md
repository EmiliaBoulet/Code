# Avoir la base trombi en local en avance ! 


On va l'appeler `tempotrombi` pour éviter les problèmes avec le cours de lundi où l'on aura une vraie base `trombi`. 

Vous pourrez la dégager lundi avec la commande `DROP DATABASE tempotrombi;`



## Installation


- On installe Postgres et son CLI si c'est pas déjà fait. 
	- `psql --version` doit fonctionner

- On essaie de se connecter à la base locale `postgres` :
	- Linux : `sudo -i -u postgres psql`
	- Window : 
		- `psql` simplement ? 
		- `psql -U postgres -d postgres` peut-être ?
		- Sinon, il faudra chercher un peu...

- Une fois dans le CLI psql :
	- on créé un utilisateur `tempotrombi` :
		- `CREATE ROLE tempotrombi WITH LOGIN PASSWORD 'tempotrombi';`
	- on créé une database tempotrombi :
		- `CREATE DATABASE tempotrombi OWNER tempotrombi;`
	- on se connecte à cette DB avec l'utilisateur tempotrombi :
		- `\c tempotrombi tempotrombi`
	- on importe les données pour cette base :
		- `\i <chemin_vers_le_fichier_sql_qui_se_trouve_dans_ce_zip/create_db.sql>`

## Connexion depuis Node pg:

Du coup, au niveau de la config : 
- host : "localhost"
- user : "tempotrombi"
- password : "tempotrombi"
- database : "tempotrombi"



Bon courage ! 
Et bon weekend \(ツ)/
